hello_world <- function() {
  print('Hello, world!')
}